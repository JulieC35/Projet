/**
 * Stores the possible different languages;
 */

package lang;

public enum Language{
	FRENCH,
	ENGLISH;
}