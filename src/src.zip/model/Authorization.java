package model;

public enum Authorization{
	ADMIN,
	DEFAULT,
	RESTRICTED;
}