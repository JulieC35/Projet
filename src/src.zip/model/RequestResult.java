package model;

public enum RequestResult{
	END,
	ERROR,
	OK;
}