//import org.junit.*; 
//import static org.junit.Assert.*; 

package test;

public class TestApplication{

	/*private Application app1;
	private Application app2;

	/*
	 * Initialise les objets avant chaque tests
	 */
	/*@Before()
	protected void beforeTest(){
		app1 = new Application();
		app2 = new Application();
	}

	/*
	 * Nettoie les objets après chaque tests
	 */
	/*@After()
	protected void clearTest(){
		user1 = null;
		user2 = null;
	}


	/*
	 * Test de la méthode login de la classe Application
	 */
	/*@Test()
	public void testLogin(){
		Assert.assertTrue(app1.checkLoginInfos());
	}

	

	/*
	 * test de la méthode connect de la classe Application
	 */
	/*@Test()
	public void testConnect(){
		Assert.assertTrue(dbC.testConnectivity());
	}*/

}